interface HomeScreenProps {
  onSearch: () => void;
  onProfile: () => void;
}

export function HomeScreen({ onSearch, onProfile }: HomeScreenProps) {
  return (
    <div className="w-full h-full bg-white overflow-y-auto">
      {/* Header with Profile */}
      <div className="flex justify-between items-center p-6 border-b-2 border-[#D9D9D9]">
        <div className="text-xl text-[#666]">Train Tracker</div>
        <div 
          className="w-10 h-10 border-2 border-[#D9D9D9] rounded-full cursor-pointer"
          onClick={onProfile}
        />
      </div>
      
      {/* Search Bar Placeholder */}
      <div className="p-6">
        <div 
          className="w-full h-12 border-2 border-[#D9D9D9] bg-white flex items-center px-4 cursor-pointer"
          onClick={onSearch}
        >
          <span className="text-[#CCC] text-sm">Search train number or name...</span>
        </div>
      </div>
      
      {/* Quick Options Section */}
      <div className="px-6 mb-8">
        <div className="text-sm text-[#666] mb-4">Quick Options</div>
        
        <div className="grid grid-cols-2 gap-4">
          <div 
            className="aspect-square border-2 border-[#D9D9D9] bg-white flex items-center justify-center cursor-pointer"
            onClick={onSearch}
          >
            <span className="text-[#666] text-sm">Live Status</span>
          </div>
          <div className="aspect-square border-2 border-[#D9D9D9] bg-white flex items-center justify-center">
            <span className="text-[#666] text-sm">PNR</span>
          </div>
          <div className="aspect-square border-2 border-[#D9D9D9] bg-white flex items-center justify-center">
            <span className="text-[#666] text-sm">Stations</span>
          </div>
          <div className="aspect-square border-2 border-[#D9D9D9] bg-white flex items-center justify-center">
            <span className="text-[#666] text-sm">Schedule</span>
          </div>
        </div>
      </div>
      
      {/* Recent Searches Section */}
      <div className="px-6">
        <div className="text-sm text-[#666] mb-4">Recent Searches</div>
        
        <div className="space-y-3">
          {[1, 2, 3].map((item) => (
            <div 
              key={item}
              className="h-16 border-2 border-[#D9D9D9] bg-white flex items-center px-4 cursor-pointer"
              onClick={onSearch}
            >
              <div className="flex-1">
                <div className="text-sm text-[#666] mb-1">Train Name {item}</div>
                <div className="text-xs text-[#999]">Station A → Station B</div>
              </div>
              <div className="text-xs text-[#999]">12345</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
