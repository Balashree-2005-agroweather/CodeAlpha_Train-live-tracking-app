interface StationListScreenProps {
  onBack: () => void;
}

export function StationListScreen({ onBack }: StationListScreenProps) {
  const stations = [
    { name: 'New Delhi', arr: '--', dep: '06:00', status: 'completed', platform: '3' },
    { name: 'Mathura Jn', arr: '08:15', dep: '08:20', status: 'completed', platform: '2' },
    { name: 'Agra Cantt', arr: '09:00', dep: '09:05', status: 'completed', platform: '1' },
    { name: 'Gwalior', arr: '10:30', dep: '10:35', status: 'completed', platform: '4' },
    { name: 'Jhansi Jn', arr: '12:00', dep: '12:10', status: 'completed', platform: '2' },
    { name: 'Bhopal Jn', arr: '15:45', dep: '15:55', status: 'current', platform: '3' },
    { name: 'Itarsi Jn', arr: '17:30', dep: '17:35', status: 'upcoming', platform: '1' },
    { name: 'Nagpur', arr: '20:15', dep: '20:25', status: 'upcoming', platform: '2' },
    { name: 'Pune Jn', arr: '04:30', dep: '04:40', status: 'upcoming', platform: '5' },
    { name: 'Mumbai CST', arr: '10:30', dep: '--', status: 'upcoming', platform: '7' }
  ];

  return (
    <div className="w-full h-full bg-white overflow-y-auto">
      {/* Header */}
      <div className="flex items-center p-6 border-b-2 border-[#D9D9D9]">
        <div 
          className="w-8 h-8 border-2 border-[#D9D9D9] mr-4 cursor-pointer"
          onClick={onBack}
        >
          <span className="text-xs text-[#999]">&lt;</span>
        </div>
        <div className="text-lg text-[#666]">All Stations</div>
      </div>
      
      {/* Station List */}
      <div className="p-6">
        <div className="space-y-0">
          {stations.map((station, idx) => (
            <div key={idx} className="flex gap-4">
              {/* Progress Line */}
              <div className="flex flex-col items-center pt-2">
                <div 
                  className={`w-3 h-3 border-2 ${
                    station.status === 'current' 
                      ? 'border-[#666] bg-[#666]' 
                      : 'border-[#D9D9D9] bg-white'
                  }`} 
                />
                {idx < stations.length - 1 && (
                  <div 
                    className={`w-0.5 h-20 ${
                      station.status === 'completed' 
                        ? 'bg-[#666]' 
                        : 'bg-[#D9D9D9]'
                    }`} 
                  />
                )}
              </div>
              
              {/* Station Info */}
              <div className="flex-1 py-2 pb-6 border-b border-[#E5E5E5]">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <div className={`text-sm mb-1 ${
                      station.status === 'current' 
                        ? 'text-[#333]' 
                        : 'text-[#666]'
                    }`}>
                      {station.name}
                    </div>
                    <div className="text-xs text-[#999]">Platform {station.platform}</div>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-xs text-[#999] mb-1">
                      Arr: {station.arr}
                    </div>
                    <div className="text-xs text-[#999]">
                      Dep: {station.dep}
                    </div>
                  </div>
                </div>
                
                {station.status === 'current' && (
                  <div className="mt-2">
                    <div className="inline-block px-2 py-1 border border-[#D9D9D9] bg-white">
                      <span className="text-xs text-[#666]">CURRENT</span>
                    </div>
                  </div>
                )}
                
                {station.status === 'completed' && (
                  <div className="text-xs text-[#999] mt-1">Departed</div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}