interface SplashScreenProps {
  onNext: () => void;
}

export function SplashScreen({ onNext }: SplashScreenProps) {
  return (
    <div className="w-full h-full bg-white flex flex-col items-center justify-center p-8" onClick={onNext}>
      {/* Placeholder Logo Box */}
      <div className="w-40 h-40 border-4 border-[#D9D9D9] bg-white mb-8 flex items-center justify-center">
        <span className="text-[#999] text-xs">LOGO</span>
      </div>
      
      {/* App Name */}
      <div className="text-center">
        <div className="text-2xl text-[#666] mb-2">Train Tracker</div>
        <div className="text-sm text-[#999]">Live tracking app</div>
      </div>
    </div>
  );
}
