interface LoginScreenProps {
  onNext: () => void;
}

export function LoginScreen({ onNext }: LoginScreenProps) {
  return (
    <div className="w-full h-full bg-white p-8">
      {/* Header */}
      <div className="mt-16 mb-16">
        <div className="text-3xl text-[#666]">Login</div>
      </div>
      
      {/* Phone Number Input Placeholder */}
      <div className="mb-8">
        <div className="text-xs text-[#999] mb-2">Phone Number</div>
        <div className="w-full h-12 border-2 border-[#D9D9D9] bg-white flex items-center px-4">
          <span className="text-[#CCC] text-sm">+91 XXXXXXXXXX</span>
        </div>
      </div>
      
      {/* OTP Button Placeholder */}
      <div className="mb-8">
        <div 
          className="w-full h-12 border-2 border-[#D9D9D9] bg-white flex items-center justify-center cursor-pointer"
          onClick={onNext}
        >
          <span className="text-[#666] text-sm">Get OTP</span>
        </div>
      </div>
      
      {/* Continue as Guest Link */}
      <div className="text-center mt-12">
        <div 
          className="text-sm text-[#666] underline cursor-pointer"
          onClick={onNext}
        >
          Continue as Guest
        </div>
      </div>
    </div>
  );
}
