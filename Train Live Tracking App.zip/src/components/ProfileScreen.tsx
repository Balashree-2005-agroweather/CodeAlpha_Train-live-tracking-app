interface ProfileScreenProps {
  onBack: () => void;
}

export function ProfileScreen({ onBack }: ProfileScreenProps) {
  const menuItems = [
    'My Trips',
    'Saved Trains',
    'Alerts',
    'Settings',
    'Logout'
  ];

  return (
    <div className="w-full h-full bg-white overflow-y-auto">
      {/* Header */}
      <div className="flex items-center p-6 border-b-2 border-[#D9D9D9]">
        <div 
          className="w-8 h-8 border-2 border-[#D9D9D9] mr-4 cursor-pointer"
          onClick={onBack}
        >
          <span className="text-xs text-[#999]">&lt;</span>
        </div>
        <div className="text-lg text-[#666]">Profile</div>
      </div>
      
      {/* Profile Info */}
      <div className="flex flex-col items-center pt-12 pb-8 border-b-2 border-[#D9D9D9]">
        {/* Profile Picture Placeholder */}
        <div className="w-24 h-24 border-4 border-[#D9D9D9] rounded-full bg-white mb-6 flex items-center justify-center">
          <span className="text-xs text-[#999]">PHOTO</span>
        </div>
        
        {/* Name Placeholder */}
        <div className="w-40 h-6 border-2 border-[#D9D9D9] bg-white mb-3 flex items-center justify-center">
          <span className="text-xs text-[#CCC]">User Name</span>
        </div>
        
        {/* Phone Placeholder */}
        <div className="w-32 h-5 border-2 border-[#D9D9D9] bg-white flex items-center justify-center">
          <span className="text-xs text-[#CCC]">+91 XXXXXXXXXX</span>
        </div>
      </div>
      
      {/* Menu Items */}
      <div className="p-6">
        <div className="space-y-3">
          {menuItems.map((item, idx) => (
            <div 
              key={idx}
              className="h-14 border-2 border-[#D9D9D9] bg-white flex items-center justify-between px-4 cursor-pointer"
            >
              <span className="text-sm text-[#666]">{item}</span>
              <div className="w-6 h-6 border-2 border-[#D9D9D9] flex items-center justify-center">
                <span className="text-xs text-[#999]">&gt;</span>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      {/* App Version */}
      <div className="text-center py-8">
        <div className="text-xs text-[#CCC]">Version 1.0.0</div>
      </div>
    </div>
  );
}