interface LiveTrackingScreenProps {
  onBack: () => void;
  onStations: () => void;
}

export function LiveTrackingScreen({ onBack, onStations }: LiveTrackingScreenProps) {
  return (
    <div className="w-full h-full bg-white relative">
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-10 flex items-center p-6 bg-white border-b-2 border-[#D9D9D9]">
        <div 
          className="w-8 h-8 border-2 border-[#D9D9D9] mr-4 cursor-pointer"
          onClick={onBack}
        >
          <span className="text-xs text-[#999]">&lt;</span>
        </div>
        <div className="text-lg text-[#666]">Live Tracking</div>
      </div>
      
      {/* Map Placeholder */}
      <div className="w-full h-[480px] mt-[72px] border-4 border-[#D9D9D9] bg-white relative">
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-[#CCC] text-sm">MAP VIEW</span>
        </div>
        
        {/* Train Icon Placeholder */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className="w-12 h-12 border-2 border-[#666] bg-white flex items-center justify-center">
            <span className="text-xs text-[#666]">TRAIN</span>
          </div>
        </div>
        
        {/* Route Line */}
        <div className="absolute top-1/4 left-4 right-4 h-0.5 bg-[#D9D9D9]" />
        
        {/* Station Markers */}
        <div className="absolute top-1/4 left-8 w-2 h-2 border-2 border-[#666] bg-white -translate-y-1/2" />
        <div className="absolute top-1/4 left-1/3 w-2 h-2 border-2 border-[#666] bg-white -translate-y-1/2" />
        <div className="absolute top-1/4 right-8 w-2 h-2 border-2 border-[#666] bg-white -translate-y-1/2" />
      </div>
      
      {/* Bottom Info Card */}
      <div className="absolute bottom-0 left-0 right-0 bg-white border-t-4 border-[#D9D9D9] p-6">
        <div className="mb-4">
          <div className="text-xs text-[#999] mb-1">Current Station</div>
          <div className="text-lg text-[#666]">Bhopal Junction</div>
        </div>
        
        <div className="mb-6">
          <div className="text-xs text-[#999] mb-1">Next Station</div>
          <div className="text-sm text-[#666]">Itarsi Junction</div>
        </div>
        
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="border-2 border-[#D9D9D9] p-3">
            <div className="text-xs text-[#999] mb-1">ETA</div>
            <div className="text-sm text-[#666]">45 min</div>
          </div>
          
          <div className="border-2 border-[#D9D9D9] p-3">
            <div className="text-xs text-[#999] mb-1">Speed</div>
            <div className="text-sm text-[#666]">85 km/h</div>
          </div>
        </div>
        
        {/* View All Stations Button */}
        <div 
          className="w-full h-10 border-2 border-[#D9D9D9] bg-white flex items-center justify-center cursor-pointer"
          onClick={onStations}
        >
          <span className="text-[#666] text-sm">View All Stations</span>
        </div>
      </div>
    </div>
  );
}