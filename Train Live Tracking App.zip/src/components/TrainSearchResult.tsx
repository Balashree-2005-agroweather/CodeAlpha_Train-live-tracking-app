interface TrainSearchResultProps {
  onBack: () => void;
  onTrack: () => void;
}

export function TrainSearchResult({ onBack, onTrack }: TrainSearchResultProps) {
  return (
    <div className="w-full h-full bg-white overflow-y-auto">
      {/* Header */}
      <div className="flex items-center p-6 border-b-2 border-[#D9D9D9]">
        <div 
          className="w-8 h-8 border-2 border-[#D9D9D9] mr-4 cursor-pointer"
          onClick={onBack}
        >
          <span className="text-xs text-[#999]">&lt;</span>
        </div>
        <div className="text-lg text-[#666]">Train Details</div>
      </div>
      
      {/* Train Info Card */}
      <div className="p-6">
        <div className="border-2 border-[#D9D9D9] bg-white p-6 mb-6">
          <div className="text-lg text-[#666] mb-4">Rajdhani Express</div>
          <div className="text-xs text-[#999] mb-4">Train No: 12301</div>
          
          {/* Route */}
          <div className="flex items-center justify-between mb-6">
            <div>
              <div className="text-sm text-[#666]">New Delhi</div>
              <div className="text-xs text-[#999]">06:00 AM</div>
            </div>
            
            <div className="flex-1 mx-4 border-t-2 border-[#D9D9D9] relative">
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white px-2">
                <span className="text-xs text-[#999]">16h 30m</span>
              </div>
            </div>
            
            <div className="text-right">
              <div className="text-sm text-[#666]">Mumbai</div>
              <div className="text-xs text-[#999]">10:30 PM</div>
            </div>
          </div>
          
          {/* Track Button */}
          <div 
            className="w-full h-12 border-2 border-[#D9D9D9] bg-white flex items-center justify-center cursor-pointer"
            onClick={onTrack}
          >
            <span className="text-[#666] text-sm">Track Live Status</span>
          </div>
        </div>
        
        {/* Station Timeline */}
        <div className="text-sm text-[#666] mb-4">Station Timeline</div>
        
        <div className="space-y-4">
          {[
            { name: 'New Delhi', arr: '--', dep: '06:00', platform: '3' },
            { name: 'Mathura Jn', arr: '08:15', dep: '08:20', platform: '2' },
            { name: 'Agra Cantt', arr: '09:00', dep: '09:05', platform: '1' },
            { name: 'Gwalior', arr: '10:30', dep: '10:35', platform: '4' },
            { name: 'Jhansi Jn', arr: '12:00', dep: '12:10', platform: '2' },
            { name: 'Bhopal', arr: '15:45', dep: '15:55', platform: '3' }
          ].map((station, idx) => (
            <div key={idx} className="flex gap-4">
              <div className="flex flex-col items-center">
                <div className="w-3 h-3 border-2 border-[#D9D9D9] bg-white" />
                {idx < 5 && <div className="w-0.5 h-12 bg-[#D9D9D9]" />}
              </div>
              
              <div className="flex-1 pb-4">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="text-sm text-[#666] mb-1">{station.name}</div>
                    <div className="text-xs text-[#999]">Platform {station.platform}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-[#999]">Arr: {station.arr}</div>
                    <div className="text-xs text-[#999]">Dep: {station.dep}</div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}