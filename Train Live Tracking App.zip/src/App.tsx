import { useState } from 'react';
import { SplashScreen } from './components/SplashScreen';
import { LoginScreen } from './components/LoginScreen';
import { HomeScreen } from './components/HomeScreen';
import { TrainSearchResult } from './components/TrainSearchResult';
import { LiveTrackingScreen } from './components/LiveTrackingScreen';
import { StationListScreen } from './components/StationListScreen';
import { ProfileScreen } from './components/ProfileScreen';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState('splash');

  const screens = {
    splash: <SplashScreen onNext={() => setCurrentScreen('login')} />,
    login: <LoginScreen onNext={() => setCurrentScreen('home')} />,
    home: <HomeScreen 
      onSearch={() => setCurrentScreen('search')}
      onProfile={() => setCurrentScreen('profile')}
    />,
    search: <TrainSearchResult 
      onBack={() => setCurrentScreen('home')}
      onTrack={() => setCurrentScreen('tracking')}
    />,
    tracking: <LiveTrackingScreen 
      onBack={() => setCurrentScreen('search')}
      onStations={() => setCurrentScreen('stations')}
    />,
    stations: <StationListScreen onBack={() => setCurrentScreen('tracking')} />,
    profile: <ProfileScreen onBack={() => setCurrentScreen('home')} />
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-white p-8">
      {/* iPhone 14 Frame */}
      <div className="w-[390px] h-[844px] bg-white border-4 border-gray-400 relative overflow-hidden">
        {screens[currentScreen]}
      </div>
      
      {/* Navigation Helper */}
      <div className="fixed top-4 right-4 bg-white border-2 border-gray-300 p-4 rounded">
        <div className="text-sm mb-2">Navigate Screens:</div>
        <div className="flex flex-col gap-2">
          <button 
            onClick={() => setCurrentScreen('splash')}
            className="px-3 py-1 border border-gray-400 hover:bg-gray-100 text-sm"
          >
            1. Splash
          </button>
          <button 
            onClick={() => setCurrentScreen('login')}
            className="px-3 py-1 border border-gray-400 hover:bg-gray-100 text-sm"
          >
            2. Login
          </button>
          <button 
            onClick={() => setCurrentScreen('home')}
            className="px-3 py-1 border border-gray-400 hover:bg-gray-100 text-sm"
          >
            3. Home
          </button>
          <button 
            onClick={() => setCurrentScreen('search')}
            className="px-3 py-1 border border-gray-400 hover:bg-gray-100 text-sm"
          >
            4. Search Result
          </button>
          <button 
            onClick={() => setCurrentScreen('tracking')}
            className="px-3 py-1 border border-gray-400 hover:bg-gray-100 text-sm"
          >
            5. Live Tracking
          </button>
          <button 
            onClick={() => setCurrentScreen('stations')}
            className="px-3 py-1 border border-gray-400 hover:bg-gray-100 text-sm"
          >
            6. Station List
          </button>
          <button 
            onClick={() => setCurrentScreen('profile')}
            className="px-3 py-1 border border-gray-400 hover:bg-gray-100 text-sm"
          >
            7. Profile
          </button>
        </div>
      </div>
    </div>
  );
}
